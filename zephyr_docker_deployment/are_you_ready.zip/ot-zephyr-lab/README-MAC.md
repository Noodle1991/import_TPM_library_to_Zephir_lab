> **Актуальный запуск готового архива:** см. [`QUICKSTART-GDB.md`](QUICKSTART-GDB.md).
> Новый образ называется `ot-zephyr-lab-gdb-ready`; upstream-патч для OpenTitan/JTAG встроен в Dockerfile.
> Достаточно `./scripts/setup-and-check.sh` после `chmod +x scripts/*.sh container/scripts/*.sh`.

# Zephyr 3.7.0 на OpenTitan EarlGrey: macOS, Docker, GDB и OpenOCD

Проект основан на исходном `ot-zephyr-lab-mac.zip`. Состав системы:

- Zephyr `v3.7.0` и SDK `0.16.5-1` с RISC-V компилятором и GDB;
- OpenTitan EarlGrey на коммите `fee8a58ebe`;
- Verilator `4.210` и совместимый с OpenTitan OpenOCD, собранный Bazel;
- Docker (Ubuntu 22.04), приложение `myapp`, скрипты сборки/запуска/отладки.

## Требования

Установите и запустите Docker Desktop на macOS. Желательно выделить Docker не
менее 16 ГБ оперативной памяти и достаточно места на диске (сборка OpenTitan
и Verilator довольно объёмная). На Apple Silicon используется эмуляция
контейнера `linux/amd64`, поэтому сборка и работа симулятора могут быть медленными.
Инструменты отладки отдельно на Mac устанавливать не требуется.

Проверьте `docker info` в терминале.

## 1. Развернуть всю среду и проверить отладчик

Распакуйте архив и выполните из папки `ot-zephyr-lab`:

```bash
chmod +x scripts/*.sh container/scripts/*.sh
./scripts/setup-and-check.sh
```

Эта команда:

1. Создаёт образ `ot-zephyr-lab-gdb-ready` и во время сборки скачивает Zephyr, SDK,
   исходники OpenTitan и остальные зависимости.
2. Вместе с SDK получает `riscv64-zephyr-elf-gdb`, проверяет запуск GDB.
3. Через Bazel собирает OpenOCD с поддержкой `remote_bitbang`.
4. Проверяет наличие GDB, OpenOCD, Verilator.
5. Собирает стандартный `samples/hello_world` Zephyr.
6. Запускает OpenTitan в Verilator, проверяет UART, затем запускает OpenOCD и
   **запускает GDB в пакетном режиме** с командами `target extended-remote`,
   `monitor halt`, `info registers pc sp`, `monitor resume`.
7. Показывает вывод GDB в терминале и сохраняет в лог. При ошибке проверка
   завершается с ненулевым кодом.

Вывод успешной проверки содержит строку вида:

```text
[PASS] Zephyr executed in Verilator and printed to UART:
Hello World! opentitan_earlgrey/opentitan
[GDB] Connecting to OpenOCD localhost:3333 (JTAG remote_bitbang 44853)
... фактический вывод GDB c регистрами pc и sp ...
[PASS] GDB -> OpenOCD -> virtual JTAG: PC and SP retrieved
```

**Это пример структуры вывода, не результат реального запуска.** Значения
`pc` и `sp` скрипт получает от симулятора при выполнении команды, заранее
они не задаются.

## 2. Где найти результат

```text
logs/smoke_hello_world.uart0.log     # вывод Zephyr по UART
logs/smoke_hello_world.sim.log       # stdout симулятора
logs/smoke_hello_world.openocd.log   # подключение OpenOCD
logs/smoke_hello_world.gdb.log       # реальный вывод GDB
build/smoke_hello_world/zephyr/zephyr.elf
```

Повторить тест без пересборки Docker-образа:

```bash
./scripts/smoke-test.sh
```

Проверить наличие инструментов без запуска симулятора:

```bash
./scripts/check-debug-tools.sh
```

## 3. Собрать и отлаживать своё приложение

```bash
./scripts/build-app.sh myapp hello_demo
./scripts/debug-app.sh hello_demo
```

`debug-app.sh` запускает контейнер `ot-zephyr-debug`, поднимает Verilator и
OpenOCD и **сразу выводит значения `pc` и `sp` через GDB**. Проверка также
создаёт `logs/manual.gdb.log`. Симуляция остаётся работать для отладки
(по умолчанию не более 900 секунд).

Для подключения вручную:

```bash
./scripts/gdb-connect.sh
```

Внутри интерактивного сеанса GDB доступны стандартные команды:

```gdb
info registers
break main
continue
bt
quit
```

Дополнительный снимок регистров:

```bash
./scripts/gdb-snapshot.sh
```

Остановить отладочный контейнер:

```bash
./scripts/stop-debug.sh
```

GDB работает внутри того же Docker-контейнера, что и OpenOCD. Сервер
OpenOCD слушает `localhost:3333`, а виртуальный JTAG симулятора `:44853`.
Наружу на Mac эти порты не публикуются.

## 4. Обычный запуск без отладчика

```bash
./scripts/build-app.sh myapp hello_demo
./scripts/run-app.sh hello_demo
```

`run-app.sh` выводит UART (в интерактивном терминале), записывает логи в
`logs/`. Остановить симуляцию можно `Ctrl+C`.

Открыть командную строку в контейнере:

```bash
./scripts/shell.sh
```

Исходники Zephyr внутри контейнера находятся в `/home/dev/zephyrproject/zephyr`,
OpenTitan — в `/home/dev/opentitan`, а каталог проекта смонтирован в `/workspace`.

## 5. Если проверка не прошла

- `docker: command not found`: установите Docker Desktop.
- `Killed`, ошибка 137: возможно, не хватает оперативной памяти Docker.
- Ошибка GDB: сначала изучите `logs/smoke_hello_world.openocd.log`, затем
  `logs/smoke_hello_world.sim.log` и `logs/smoke_hello_world.gdb.log`.
- Отсутствует ELF: заново соберите приложение командой `build-app.sh`.
- Ошибка `Permission denied` на `build/` или `logs/`: проверьте владельца
  этих каталогов, не запускайте все скрипты через `sudo`.

Этот пакет подготовлен и проверен на уровне структуры файлов и синтаксиса
скриптов, но полноценная сборка OpenTitan и запуск Docker на вашем Mac
здесь не выполнялись — результат реальной отладки должен подтвердить
`setup-and-check.sh` при запуске у вас.
