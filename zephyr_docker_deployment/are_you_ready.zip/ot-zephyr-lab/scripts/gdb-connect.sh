#!/usr/bin/env bash
set -euo pipefail
CONTAINER_NAME="${1:-ot-zephyr-debug}"
# Interactive GDB in the same Docker network namespace as OpenOCD.
# GDB halts the target when connected. Type 'continue' to resume.
docker exec -it "$CONTAINER_NAME" /bin/bash -lc '
  set -e
  source /home/dev/scripts/sim_helpers.sh
  resolve_debug_tools
  ELF="${DEBUG_ELF:?Missing DEBUG_ELF from debug container}"
  if [[ -z "$ELF" ]]; then echo "ERROR: no Zephyr ELF" >&2; exit 1; fi
  echo "Connecting GDB to OpenOCD with $ELF"
  exec "$GDB_BIN" -nx -q "$ELF" -ex "set pagination off" -ex "set remotetimeout 30" -ex "target remote localhost:3333" -ex "info registers pc"
'
