#!/bin/bash

set -euo pipefail

OTZL_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OTZL_IMAGE_NAME="${OTZL_IMAGE_NAME:-ot-zephyr-lab-gdb-ready}"
OTZL_CONTAINER_WORKSPACE="/workspace"
OTZL_LOGS_DIR="${OTZL_ROOT}/logs"
OTZL_BUILD_DIR="${OTZL_ROOT}/build"
OTZL_OWNER_UID="${SUDO_UID:-$(id -u)}"
OTZL_OWNER_GID="${SUDO_GID:-$(id -g)}"

ensure_host_dirs() {
    if [[ "$(id -u)" -eq 0 ]]; then
        install -d -m 0775 -o "${OTZL_OWNER_UID}" -g "${OTZL_OWNER_GID}" \
            "${OTZL_LOGS_DIR}" "${OTZL_BUILD_DIR}"
        chown -R "${OTZL_OWNER_UID}:${OTZL_OWNER_GID}" \
            "${OTZL_LOGS_DIR}" "${OTZL_BUILD_DIR}"
    else
        mkdir -p "${OTZL_LOGS_DIR}" "${OTZL_BUILD_DIR}"
    fi
}

ensure_host_dirs

docker_ready() {
    docker info >/dev/null 2>&1
}

require_docker() {
    if ! command -v docker >/dev/null 2>&1; then
        echo "ERROR: docker not found in PATH." >&2
        exit 1
    fi
    if ! docker_ready; then
        echo "ERROR: Docker daemon is unavailable." >&2
        echo "Start Docker and rerun the command." >&2
        exit 1
    fi
}

ensure_image() {
    require_docker
    if ! docker image inspect "${OTZL_IMAGE_NAME}" >/dev/null 2>&1; then
        echo "ERROR: image ${OTZL_IMAGE_NAME} is missing." >&2
        echo "Run ./scripts/build-image.sh first." >&2
        exit 1
    fi
}

run_in_container() {
    local options=()

    while [[ $# -gt 0 ]]; do
        if [[ "$1" == "--" ]]; then
            shift
            break
        fi
        options+=("$1")
        shift
    done

    docker run --rm --platform linux/amd64 ${options[@]+"${options[@]}"} \
        -v "${OTZL_ROOT}:${OTZL_CONTAINER_WORKSPACE}" \
        -v "${OTZL_ROOT}/container/scripts/sim_helpers.sh:/home/dev/scripts/sim_helpers.sh:ro" \
        -w "${OTZL_CONTAINER_WORKSPACE}" \
        "${OTZL_IMAGE_NAME}" \
        "$@"
}
