#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"
ensure_image
BUILD_NAME=smoke_hello_world
run_in_container -- /bin/bash -lc "cd /home/dev/zephyrproject/zephyr && \
  west build -b opentitan_earlgrey samples/hello_world \
  --build-dir /workspace/build/${BUILD_NAME} --pristine \
  -- -DPython3_EXECUTABLE=/usr/bin/python3.12"
run_in_container \
  -e "UART_LOG=/workspace/logs/${BUILD_NAME}.uart0.log" \
  -e "SIM_LOG=/workspace/logs/${BUILD_NAME}.sim.log" \
  -e "OCD_LOG=/workspace/logs/${BUILD_NAME}.openocd.log" \
  -e "GDB_LOG=/workspace/logs/${BUILD_NAME}.gdb.log" \
  -e "SIM_TIMEOUT_SECONDS=${SIM_TIMEOUT_SECONDS:-600}" \
  -e 'SMOKE_EXPECT=Hello World! opentitan_earlgrey' \
  -e 'SMOKE_GDB=1' -- \
  /workspace/container/scripts/run_smoke.sh \
  /workspace/build/${BUILD_NAME}/zephyr/zephyr.elf
