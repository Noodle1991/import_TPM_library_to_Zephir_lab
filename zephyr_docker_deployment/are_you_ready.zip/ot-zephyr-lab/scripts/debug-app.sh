#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"
[[ $# -ge 1 && $# -le 2 ]] || { echo "Usage: $0 <build-name> [container-name]" >&2; exit 2; }
BUILD_NAME="$1"
CONTAINER_NAME="${2:-ot-zephyr-debug}"
ELF="${OTZL_BUILD_DIR}/${BUILD_NAME}/zephyr/zephyr.elf"
[[ -f "$ELF" ]] || { echo "Missing $ELF: build the app first" >&2; exit 1; }
ensure_image
if docker container inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
  echo "ERROR: container already exists: $CONTAINER_NAME (stop it first)" >&2
  exit 1
fi
docker run -d --rm --platform linux/amd64 --name "$CONTAINER_NAME" \
  -e "DEBUG_LOG_BASE=/workspace/logs/${BUILD_NAME}.debug" \
  -e "DEBUG_ELF=/workspace/build/${BUILD_NAME}/zephyr/zephyr.elf" \
  -e "DEBUG_SIM_TIMEOUT_SECONDS=${DEBUG_SIM_TIMEOUT_SECONDS:-900}" \
  -v "${OTZL_ROOT}:/workspace" \
  -v "${OTZL_ROOT}/container/scripts/sim_helpers.sh:/home/dev/scripts/sim_helpers.sh:ro" \
  -w /workspace "$OTZL_IMAGE_NAME" \
  /workspace/container/scripts/start_debug.sh "/workspace/build/${BUILD_NAME}/zephyr/zephyr.elf" >/dev/null
echo "[START] Debugging container: $CONTAINER_NAME"
echo "[CHECK] Waiting for OpenOCD and GDB server to initialize"
READY=0
for ((i=0;i<120;i++)); do
  if docker logs "$CONTAINER_NAME" 2>&1 | grep -q '^\[READY\] GDB :3333'; then
    READY=1
    break
  fi
  if [[ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER_NAME" 2>/dev/null || true)" != true ]]; then
    echo '[FAIL] Debug container stopped before GDB server was ready' >&2
    docker logs "$CONTAINER_NAME" 2>&1 | tail -n 40 || true
    exit 1
  fi
  sleep 1
done
if [[ "$READY" != 1 ]]; then
  echo '[FAIL] OpenOCD initialization timeout; inspect the container logs' >&2
  docker logs "$CONTAINER_NAME" 2>&1 | tail -n 40 || true
  exit 1
fi
echo '[READY] OpenOCD GDB server is listening on port 3333 inside Docker'
echo '[CHECK] Automatic post-start GDB register readout:'
if ! "$SCRIPT_DIR/gdb-snapshot.sh" "$CONTAINER_NAME"; then
  echo '[FAIL] GDB verification failed; see logs and OpenOCD output' >&2
  docker logs "$CONTAINER_NAME" 2>&1 | tail -n 30 || true
  "$SCRIPT_DIR/stop-debug.sh" "$CONTAINER_NAME" || true
  exit 1
fi
echo "[INFO] ./scripts/gdb-connect.sh $CONTAINER_NAME  # interactive GDB"
echo "[STOP] ./scripts/stop-debug.sh $CONTAINER_NAME"
