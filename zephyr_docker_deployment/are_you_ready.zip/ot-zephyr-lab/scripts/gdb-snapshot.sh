#!/usr/bin/env bash
set -euo pipefail
CONTAINER_NAME="${1:-ot-zephyr-debug}"
# Runs in the same Docker network namespace as OpenOCD, so localhost:3333 works.
docker exec "$CONTAINER_NAME" /bin/bash -lc '
  set -euo pipefail
  ELF="${DEBUG_ELF:?Missing DEBUG_ELF from debug container}"
  /home/dev/scripts/probe_gdb.sh "$ELF" /workspace/logs/manual.gdb.log
'
