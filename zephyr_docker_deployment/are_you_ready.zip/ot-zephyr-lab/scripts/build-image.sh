#!/bin/bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/common.sh"

require_docker

echo "Building image ${OTZL_IMAGE_NAME}"
echo "Context: ${OTZL_ROOT}"

docker build --platform linux/amd64 --progress=plain "$@" -t "${OTZL_IMAGE_NAME}" "${OTZL_ROOT}"
