#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"
ensure_image
run_in_container -- /bin/bash -lc '
  set -euo pipefail
  source /home/dev/scripts/sim_helpers.sh
  resolve_sim_assets
  resolve_debug_tools
  test -r /home/dev/opentitan/util/openocd/board/lowrisc-earlgrey-verilator.cfg
  echo "[CHECK] Verilator: $SIM_BIN"
  echo "[CHECK] OpenOCD: $OCD_WRAPPER"
  echo "[CHECK] GDB: $GDB_BIN"
  "$GDB_BIN" --version | sed -n '1p'
  echo "[PASS] Debugger and simulator available in the Docker image"
'
