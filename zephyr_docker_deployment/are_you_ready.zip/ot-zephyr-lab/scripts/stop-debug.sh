#!/usr/bin/env bash
set -euo pipefail
CONTAINER_NAME="${1:-ot-zephyr-debug}"
if docker container inspect "$CONTAINER_NAME" >/dev/null 2>&1; then
  docker stop -t 8 "$CONTAINER_NAME"
  echo "[STOPPED] $CONTAINER_NAME"
else
  echo "[INFO] $CONTAINER_NAME is not running"
fi
