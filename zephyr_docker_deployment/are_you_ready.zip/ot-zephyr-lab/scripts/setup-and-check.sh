#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/common.sh"

if (( $# != 0 )); then
  echo "Usage: $0" >&2
  exit 2
fi

require_docker
BASE_IMAGE="${OTZL_BASE_IMAGE:-ot-zephyr-lab:latest}"
DMI_FIX_LABEL="$(docker image inspect --format '{{ index .Config.Labels "org.otzl.dmi-fixes" }}' "$OTZL_IMAGE_NAME" 2>/dev/null || true)"

BUNDLE_VERSION="$(docker image inspect --format '{{ index .Config.Labels "org.otzl.bundle-version" }}' "$OTZL_IMAGE_NAME" 2>/dev/null || true)"

if [[ "$DMI_FIX_LABEL" == 'f14af55+59a52a1' && "$BUNDLE_VERSION" == '2' ]]; then
  echo "[CHECK] Patched Docker image $OTZL_IMAGE_NAME exists; skipping rebuild"
elif [[ "$OTZL_IMAGE_NAME" != "$BASE_IMAGE" ]] \
     && docker image inspect "$BASE_IMAGE" >/dev/null 2>&1 \
     && docker run --rm --platform linux/amd64 --entrypoint /bin/bash "$BASE_IMAGE" -lc \
        'test -f /home/dev/opentitan/hw/dv/dpi/dmidpi/dmidpi.c && test -f /home/dev/opentitan/bazel-bin/third_party/openocd/openocd.sh && test -x /tools/zephyr-sdk-0.16.5-1/riscv64-zephyr-elf/bin/riscv64-zephyr-elf-gdb' >/dev/null 2>&1; then
  echo "[BUILD] Reusing existing image $BASE_IMAGE (and cached Bazel when present)"
  docker build --platform linux/amd64 --progress=plain \
    --build-arg "BASE_IMAGE=$BASE_IMAGE" \
    -f "$OTZL_ROOT/Dockerfile.cached-gdb" \
    -t "$OTZL_IMAGE_NAME" "$OTZL_ROOT"
else
  echo "[BUILD] First setup: full image $OTZL_IMAGE_NAME (Bazel is installed inside Docker)"
  bash "$SCRIPT_DIR/build-image.sh"
fi

bash "$SCRIPT_DIR/check-debug-tools.sh"
bash "$SCRIPT_DIR/smoke-test.sh"
echo '[PASS] Deployment and automatic GDB/OpenOCD check finished'
