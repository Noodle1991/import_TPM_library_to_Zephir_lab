#!/bin/bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/common.sh"

if [[ $# -lt 1 || $# -gt 2 ]]; then
    echo "Usage: $0 <elf-path|build-name> [container-name]" >&2
    exit 1
fi

TARGET="$1"
CONTAINER_NAME="${2:-ot-zephyr-sim}"

if [[ -f "${TARGET}" ]]; then
    ELF_PATH="$(cd "$(dirname "${TARGET}")" && pwd)/$(basename "${TARGET}")"
else
    ELF_PATH="${OTZL_BUILD_DIR}/${TARGET}/zephyr/zephyr.elf"
fi

if [[ ! -f "${ELF_PATH}" ]]; then
    echo "ERROR: ELF not found: ${ELF_PATH}" >&2
    exit 1
fi

LOG_BASENAME="$(basename "$(dirname "$(dirname "${ELF_PATH}")")")"
mkdir -p "${OTZL_LOGS_DIR}"

ensure_image

docker run --rm -it \
    --name "${CONTAINER_NAME}" \
    -e UART_LOG="${OTZL_CONTAINER_WORKSPACE}/logs/${LOG_BASENAME}.uart0.log" \
    -e SIM_LOG="${OTZL_CONTAINER_WORKSPACE}/logs/${LOG_BASENAME}.sim.log" \
    -v "${OTZL_ROOT}:${OTZL_CONTAINER_WORKSPACE}" \
    -w "${OTZL_CONTAINER_WORKSPACE}" \
    "${OTZL_IMAGE_NAME}" \
    /workspace/container/scripts/run_program.sh "${OTZL_CONTAINER_WORKSPACE}${ELF_PATH#${OTZL_ROOT}}"
