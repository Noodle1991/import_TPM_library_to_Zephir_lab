#!/bin/bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/common.sh"

if [[ $# -lt 1 || $# -gt 2 ]]; then
    echo "Usage: $0 <app-dir> [build-name]" >&2
    exit 1
fi

APP_DIR="$1"
APP_PATH="${OTZL_ROOT}/${APP_DIR}"

if [[ ! -d "${APP_PATH}" ]]; then
    echo "ERROR: app directory not found: ${APP_DIR}" >&2
    exit 1
fi

BUILD_NAME="${2:-$(basename "${APP_DIR}")}"
BUILD_PATH="${OTZL_BUILD_DIR}/${BUILD_NAME}"
# Под sudo каталог должен принадлежать исходному пользователю (uid 1000),
# иначе контейнерный dev (uid 1000) не сможет писать в него.
if [[ "$(id -u)" -eq 0 ]]; then
    install -d -m 0775 -o "${OTZL_OWNER_UID}" -g "${OTZL_OWNER_GID}" "${BUILD_PATH}"
else
    mkdir -p "${BUILD_PATH}"
fi

ensure_image

run_in_container -- \
    /bin/bash -lc "cd /home/dev/zephyrproject/zephyr && \
    west build -b opentitan_earlgrey \
      ${OTZL_CONTAINER_WORKSPACE}/${APP_DIR} \
      --build-dir ${OTZL_CONTAINER_WORKSPACE}/build/${BUILD_NAME} \
      --pristine \
      -- -DPython3_EXECUTABLE=/usr/bin/python3.12"

echo "Build complete: ${BUILD_PATH}/zephyr/zephyr.elf"
