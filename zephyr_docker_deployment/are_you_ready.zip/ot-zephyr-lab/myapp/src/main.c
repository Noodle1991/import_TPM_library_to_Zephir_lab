#include <zephyr/kernel.h>

int main(void)
{
    printk("Hello from myapp!\n");
    return 0;
}
