#!/usr/bin/env bash
set -euo pipefail
source /home/dev/scripts/sim_helpers.sh
ELF="${1:?Usage: start_debug.sh <ELF path>}"
LOG_BASE="${DEBUG_LOG_BASE:-/workspace/logs/debug}"
TIME_LIMIT="${DEBUG_SIM_TIMEOUT_SECONDS:-900}"
mkdir -p "$(dirname "$LOG_BASE")"
resolve_sim_assets
resolve_debug_tools
SIM_PID=''
OCD_PID=''
WATCHDOG_PID=''
cleanup_debug_session() {
  [[ -n "$WATCHDOG_PID" ]] && kill "$WATCHDOG_PID" 2>/dev/null || true
  cleanup_sim_debug
}
trap cleanup_debug_session EXIT
trap 'exit 143' TERM INT
launch_sim "$ELF" "${LOG_BASE}.sim.log"
wait_sim_jtag 60
launch_openocd "${LOG_BASE}.openocd.log"
wait_gdb_port 60
printf '[READY] GDB :3333; ELF=%s\n' "$ELF"
echo "[READY] Auto-stop after ${TIME_LIMIT}s. Use ./scripts/gdb-connect.sh or gdb-snapshot.sh"
(
  sleep "$TIME_LIMIT"
  echo '[TIMEOUT] Ending the RTL simulation' >&2
  kill "$SIM_PID" 2>/dev/null || true
) &
WATCHDOG_PID=$!
wait "$SIM_PID" || true
[[ -f "$OT_REPO/uart0.log" ]] && cp "$OT_REPO/uart0.log" "${LOG_BASE}.uart0.log" || true
