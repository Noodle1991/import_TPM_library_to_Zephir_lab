#!/bin/bash
set -e

BAZEL_CACHE="${HOME}/.cache/bazel"

if [ ! -d "${BAZEL_CACHE}" ]; then
    echo "[fix_rules_python] Bazel cache not found at ${BAZEL_CACHE}, skipping."
    exit 0
fi

WHEEL_PY_FILES=$(find "${BAZEL_CACHE}" \
    -path "*/rules_python/python/pip_install/extract_wheels/lib/wheel.py" \
    2>/dev/null)

if [ -z "${WHEEL_PY_FILES}" ]; then
    echo "[fix_rules_python] wheel.py not found in bazel cache, skipping."
    exit 0
fi

for WHEEL_PY in ${WHEEL_PY_FILES}; do
    echo "[fix_rules_python] Patching: ${WHEEL_PY}"
    if grep -q "metadata.name is None" "${WHEEL_PY}" 2>/dev/null; then
        echo "[fix_rules_python] Already patched, skipping."
        continue
    fi

    python3 - "${WHEEL_PY}" <<'PYEOF'
import sys
path = sys.argv[1]
with open(path, 'r') as f:
    content = f.read()

old_patterns = [
    'name = "{}-{}".format(metadata.name.replace("-", "_"), metadata.version)',
    '            name = "{}-{}".format(metadata.name.replace("-", "_"), metadata.version)',
]

new_code_template = '''{indent}if metadata.name is None:
{indent}    continue
{indent}name = "{{}}-{{}}".format(metadata.name.replace("-", "_"), metadata.version)'''

patched = False
for old in old_patterns:
    if old in content:
        indent = len(old) - len(old.lstrip())
        indent_str = ' ' * indent
        new_code = new_code_template.format(indent=indent_str)
        content = content.replace(old, new_code, 1)
        patched = True
        break

if not patched:
    import re
    pattern = r'(\s+)(name\s*=\s*".*?"\s*\.format\s*\(\s*metadata\.name\.replace\(".*?".*?\))'
    match = re.search(pattern, content)
    if match:
        indent = match.group(1)
        line = match.group(2)
        new_code = f"{indent}if metadata.name is None:\n{indent}    continue\n{indent}{line}"
        content = re.sub(pattern, new_code, content, count=1)
        patched = True

if patched:
    with open(path, 'w') as f:
        f.write(content)
PYEOF
done

echo "[fix_rules_python] Done."
