#!/usr/bin/env python3
import sys
import re

def patch(path: str) -> None:
    with open(path, "r") as f:
        content = f.read()

    if "timer@40100000" in content:
        print(f"[patch_dtsi] Already patched: {path}")
        return

    if "timer@40100110" not in content:
        print(f"[patch_dtsi] WARNING: expected pattern 'timer@40100110' not found in {path}")
        return

    content = content.replace("timer@40100110", "timer@40100000")
    content = re.sub(
        r'reg\s*=\s*<0x40100110 0x8 0x40100118 0x8>',
        'reg = <0x40100000 0x4 0x40100110 0x8 0x40100118 0x8>',
        content
    )
    content = re.sub(
        r'reg-names\s*=\s*"mtime",\s*"mtimecmp"',
        'reg-names = "alert_test", "mtime", "mtimecmp"',
        content
    )

    with open(path, "w") as f:
        f.write(content)

    print(f"[patch_dtsi] Patched successfully: {path}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)
    patch(sys.argv[1])
