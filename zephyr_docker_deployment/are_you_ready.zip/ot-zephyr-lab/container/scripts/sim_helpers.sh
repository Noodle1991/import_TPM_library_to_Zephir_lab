#!/usr/bin/env bash
# Shared Verilator and OpenOCD discovery. Source from other scripts.
set -euo pipefail
OT_REPO=/home/dev/opentitan
BAZEL_CACHE=/home/dev/.cache/bazel

resolve_sim_assets() {
  SIM_BIN="$(find -L "$OT_REPO/bazel-bin/hw" -type f -name Vchip_sim_tb -print -quit 2>/dev/null || true)"
  ROM_IMAGE="$(find -L "$OT_REPO/bazel-out" -type f -name 'test_rom_sim_verilator*.vmem' -print -quit 2>/dev/null || true)"
  OTP_IMAGE="$(find -L "$OT_REPO/bazel-out" -type f -name 'img_rma*.vmem' -print -quit 2>/dev/null || true)"
  [[ -n "$SIM_BIN" && -x "$SIM_BIN" ]] || { echo 'ERROR: Vchip_sim_tb missing from Bazel output' >&2; return 1; }
  [[ -n "$ROM_IMAGE" && -r "$ROM_IMAGE" ]] || { echo 'ERROR: Test ROM .vmem missing' >&2; return 1; }
  [[ -n "$OTP_IMAGE" && -r "$OTP_IMAGE" ]] || { echo 'ERROR: RMA OTP .vmem missing' >&2; return 1; }
}

resolve_debug_tools() {
  OCD_WRAPPER="$OT_REPO/bazel-bin/third_party/openocd/openocd.sh"
  GDB_BIN="${ZEPHYR_SDK_INSTALL_DIR:-/tools/zephyr-sdk-0.16.5-1}/riscv64-zephyr-elf/bin/riscv64-zephyr-elf-gdb"
  [[ -f "$OCD_WRAPPER" ]] || { echo "ERROR: OpenOCD not built: $OCD_WRAPPER" >&2; return 1; }
  [[ -x "$GDB_BIN" ]] || { echo "ERROR: RISC-V GDB unavailable: $GDB_BIN" >&2; return 1; }
}

launch_sim() {
  local elf="$1" log="$2"
  [[ -f "$elf" ]] || { echo "ERROR: ELF not found: $elf" >&2; return 1; }
  cd "$OT_REPO"
  rm -f "$OT_REPO/uart0.log"
  "$SIM_BIN" --verbose-mem-load \
    --meminit=rom0,"$ROM_IMAGE" \
    --meminit=otp,"$OTP_IMAGE" \
    --meminit=flash0,"$elf" > "$log" 2>&1 < /dev/null &
  SIM_PID=$!
  echo "[SIM] PID=$SIM_PID (virtual JTAG localhost:44853)"
}

# Check a listening TCP socket without opening a connection.
# OpenTitan's Verilator remote_bitbang JTAG is single-client: connecting only
# to test the port can consume/close the session before OpenOCD connects.
port_is_listening() {
  local port="$1" hex_port table
  printf -v hex_port '%04X' "$port"
  for table in /proc/net/tcp /proc/net/tcp6; do
    [[ -r "$table" ]] || continue
    if awk -v port="$hex_port" '
      NR > 1 {
        split($2, address, ":")
        if (toupper(address[2]) == port && $4 == "0A") {
          found = 1
          exit
        }
      }
      END { exit !found }
    ' "$table"; then
      return 0
    fi
  done
  return 1
}

wait_sim_jtag() {
  local attempts="${1:-60}"
  for ((i=0; i<attempts; i++)); do
    if ! kill -0 "$SIM_PID" 2>/dev/null; then
      echo 'ERROR: Verilator stopped before JTAG opened' >&2
      return 1
    fi
    if port_is_listening 44853; then
      return 0
    fi
    sleep 1
  done
  echo 'ERROR: Verilator JTAG port 44853 was not opened' >&2
  return 1
}

launch_openocd() {
  local log="$1"
  cd "$OT_REPO"
  "$OCD_WRAPPER" -s "$OT_REPO/util/openocd" \
      -f "$OT_REPO/util/openocd/board/lowrisc-earlgrey-verilator.cfg" \
      > "$log" 2>&1 < /dev/null &
  OCD_PID=$!
  echo "[OpenOCD] PID=$OCD_PID (GDB server localhost:3333)"
}

wait_gdb_port() {
  local attempts="${1:-60}"
  for ((i=0; i<attempts; i++)); do
    if ! kill -0 "$OCD_PID" 2>/dev/null; then
      echo 'ERROR: OpenOCD exited unexpectedly' >&2
      return 1
    fi
    if port_is_listening 3333; then
      return 0
    fi
    sleep 1
  done
  echo 'ERROR: GDB server port 3333 not reachable' >&2
  return 1
}

cleanup_sim_debug() {
  if [[ -n "${OCD_PID:-}" ]]; then kill "$OCD_PID" 2>/dev/null || true; wait "$OCD_PID" 2>/dev/null || true; fi
  if [[ -n "${SIM_PID:-}" ]]; then kill "$SIM_PID" 2>/dev/null || true; wait "$SIM_PID" 2>/dev/null || true; fi
}
