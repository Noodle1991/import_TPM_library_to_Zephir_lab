#!/usr/bin/env bash
set -euo pipefail
source /home/dev/scripts/sim_helpers.sh

ELF="${1:?Usage: run_program.sh <zephyr.elf>}"
UART_LOG="${UART_LOG:-/workspace/logs/app.uart0.log}"
SIM_LOG="${SIM_LOG:-/workspace/logs/app.sim.log}"
SIM_TIMEOUT_SECONDS="${SIM_TIMEOUT_SECONDS:-900}"
mkdir -p "$(dirname "$UART_LOG")" "$(dirname "$SIM_LOG")"
resolve_sim_assets
SIM_PID=''
TAIL_PID=''
cleanup() {
  [[ -n "$TAIL_PID" ]] && kill "$TAIL_PID" 2>/dev/null || true
  [[ -n "$SIM_PID" ]] && kill "$SIM_PID" 2>/dev/null || true
  [[ -n "$SIM_PID" ]] && wait "$SIM_PID" 2>/dev/null || true
  [[ -e "$OT_REPO/uart0.log" ]] && cp "$OT_REPO/uart0.log" "$UART_LOG" || true
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
cd "$OT_REPO"
rm -f "$OT_REPO/uart0.log"
printf '[START] Verilator for up to %ss; Ctrl+C stops it\n' "$SIM_TIMEOUT_SECONDS"
timeout -k 5s "$SIM_TIMEOUT_SECONDS" "$SIM_BIN" \
  --verbose-mem-load \
  --meminit=rom0,"$ROM_IMAGE" \
  --meminit=otp,"$OTP_IMAGE" \
  --meminit=flash0,"$ELF" > "$SIM_LOG" 2>&1 < /dev/null &
SIM_PID=$!
for ((i=0;i<30;i++)); do
  [[ -f "$OT_REPO/uart0.log" ]] && break
  if ! kill -0 "$SIM_PID" 2>/dev/null; then
    echo '[ERROR] Verilator exited early' >&2
    tail -n 25 "$SIM_LOG"
    exit 1
  fi
  sleep 1
done
[[ -f "$OT_REPO/uart0.log" ]] && tail -n +1 -f "$OT_REPO/uart0.log" &
TAIL_PID=$!
wait "$SIM_PID" || true
printf '\n[STOP] Verilator exited; saved UART and simulation logs\n'
