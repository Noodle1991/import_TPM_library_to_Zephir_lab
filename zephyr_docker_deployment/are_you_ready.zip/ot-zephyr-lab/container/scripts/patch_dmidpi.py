#!/usr/bin/env python3
"""Apply the two upstream OpenTitan Verilator DMI fixes to the pinned source.

Upstream: lowRISC/opentitan commits f14af55 and 59a52a1 (PR #32394).
Fails closed if the old source no longer matches the expected version.
"""

from pathlib import Path
import re

SOURCE = Path('/home/dev/opentitan/hw/dv/dpi/dmidpi/dmidpi.c')


def patch(text: str) -> str:
    # Keep DMI response data intact across later JTAG scan updates.
    old1 = re.compile(
        r'(?m)^([ \t]*case UpdateDr:\n)([ \t]*)ctx->jtag\.dr_captured = ctx->jtag\.dr_shift_reg;[ \t]*\n'
    )
    if old1.search(text):
        if len(old1.findall(text)) != 1:
            raise RuntimeError('Unexpected number of UpdateDr assignments')
        text = old1.sub(
            lambda m: (
                m.group(1)
                + m.group(2) + 'if (ctx->jtag.ir_captured == DMIAccess) {\n'
                + m.group(2) + '  ctx->jtag.dr_captured = ctx->jtag.dr_shift_reg;\n'
                + m.group(2) + '}\n'
            ),
            text,
        )
    elif 'if (ctx->jtag.ir_captured == DMIAccess) {' not in text:
        raise RuntimeError('Cannot find the expected UpdateDr code')

    # Return the address of the previous DMI request in scan response.
    old2 = re.compile(
        r'(?m)^([ \t]*)ctx->jtag\.dr_captured = \(uint64_t\)ctx->sig\.dmi_rsp_data << 2;[ \t]*$'
    )
    if old2.search(text):
        if len(old2.findall(text)) != 1:
            raise RuntimeError('Unexpected number of response-data assignments')
        text = old2.sub(
            lambda m: (
                m.group(1)
                + 'ctx->jtag.dr_captured = (uint64_t)(ctx->sig.dmi_req_addr & 0x7f) << 34;\n'
                + m.group(1)
                + 'ctx->jtag.dr_captured |= (uint64_t)ctx->sig.dmi_rsp_data << 2;'
            ),
            text,
        )
    elif 'ctx->sig.dmi_req_addr & 0x7f' not in text:
        raise RuntimeError('Cannot find the expected DMI response code')

    return text


def main() -> None:
    before = SOURCE.read_text()
    after = patch(before)
    if after != before:
        SOURCE.write_text(after)
        print('[PATCH] Applied upstream OpenTitan Verilator DMI fixes f14af55 and 59a52a1')
    else:
        print('[PATCH] OpenTitan Verilator DMI fixes already present')


if __name__ == '__main__':
    main()
