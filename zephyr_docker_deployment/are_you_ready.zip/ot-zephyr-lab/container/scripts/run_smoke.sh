#!/usr/bin/env bash
set -euo pipefail
source /home/dev/scripts/sim_helpers.sh

ELF="${1:-}"
[[ -n "$ELF" && -f "$ELF" ]] || { echo 'Usage: run_smoke.sh <zephyr.elf>' >&2; exit 2; }
UART_LOG="${UART_LOG:-/workspace/logs/smoke.uart0.log}"
SIM_LOG="${SIM_LOG:-/workspace/logs/smoke.sim.log}"
OCD_LOG="${OCD_LOG:-/workspace/logs/smoke.openocd.log}"
GDB_LOG="${GDB_LOG:-/workspace/logs/smoke.gdb.log}"
SIM_TIMEOUT_SECONDS="${SIM_TIMEOUT_SECONDS:-600}"
SMOKE_EXPECT="${SMOKE_EXPECT:-Hello World! opentitan_earlgrey}"
SMOKE_GDB="${SMOKE_GDB:-1}"
mkdir -p "$(dirname "$UART_LOG")" "$(dirname "$SIM_LOG")" \
         "$(dirname "$OCD_LOG")" "$(dirname "$GDB_LOG")"

# Reset logs before each run, so a failed run cannot show stale output.
: > "$UART_LOG"
: > "$SIM_LOG"
: > "$OCD_LOG"
: > "$GDB_LOG"
resolve_sim_assets
resolve_debug_tools
printf '[CHECK] Zephyr GDB: '; "$GDB_BIN" --version | sed -n '1p'
printf '[CHECK] OpenOCD wrapper: %s\n' "$OCD_WRAPPER"

copy_uart_on_exit() {
  if [[ -f "$OT_REPO/uart0.log" ]]; then
    cp "$OT_REPO/uart0.log" "$UART_LOG" || true
  fi
  cleanup_sim_debug
}
trap copy_uart_on_exit EXIT
launch_sim "$ELF" "$SIM_LOG"
echo "[CHECK] Waiting up to $SIM_TIMEOUT_SECONDS seconds for UART pattern: $SMOKE_EXPECT"
found=0
for ((sec=0; sec<SIM_TIMEOUT_SECONDS; sec++)); do
  if [[ -f "$OT_REPO/uart0.log" ]] && grep -Fq "$SMOKE_EXPECT" "$OT_REPO/uart0.log"; then
    found=1
    break
  fi
  if ! kill -0 "$SIM_PID" 2>/dev/null; then
    echo '[FAIL] Verilator exited before expected UART message' >&2
    break
  fi
  if ((sec > 0 && sec % 30 == 0)); then echo "[CHECK] RTL simulation running... ${sec}s"; fi
  sleep 1
done
[[ -e "$OT_REPO/uart0.log" ]] && cp "$OT_REPO/uart0.log" "$UART_LOG" || true
if [[ "$found" != 1 ]]; then
  echo '[FAIL] UART smoke-test timeout/exit; see the saved logs' >&2
  tail -n 25 "$SIM_LOG" || true
  exit 1
fi
echo '[PASS] Zephyr executed in Verilator and printed to UART:'
tail -n 20 "$UART_LOG"

if [[ "$SMOKE_GDB" == 1 ]]; then
  if ! wait_sim_jtag 60; then
    echo '[FAIL] Virtual JTAG port 44853 unavailable' >&2
    tail -n 30 "$SIM_LOG" || true
    exit 1
  fi
  launch_openocd "$OCD_LOG"
  if ! wait_gdb_port 60; then
    echo '[FAIL] OpenOCD GDB server unavailable' >&2
    tail -n 25 "$OCD_LOG" || true
    exit 1
  fi
  # Print actual GDB stdout to the console and also save it to a log file.
  # The probe itself checks nonzero exit codes and verifies that PC and SP were read.
  if ! /home/dev/scripts/probe_gdb.sh "$ELF" "$GDB_LOG"; then
    echo '[FAIL] GDB/OpenOCD post-deployment check failed' >&2
    exit 1
  fi
fi

if [[ "$SMOKE_GDB" == 1 ]]; then
  echo "[PASS] Verification complete; UART: $UART_LOG; OpenOCD: $OCD_LOG; GDB: $GDB_LOG"
else
  echo "[PASS] UART verification complete; UART: $UART_LOG"
fi
