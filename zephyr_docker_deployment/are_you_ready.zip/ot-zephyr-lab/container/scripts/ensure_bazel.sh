#!/usr/bin/env bash
# Ensure the Bazel binary required by the pinned OpenTitan checkout is installed.
# This runs inside the Docker image, not on the host Mac.
set -euo pipefail

OT_REPO="${OT_REPO:-/home/dev/opentitan}"
VERSION_FILE="$OT_REPO/.bazelversion"
[[ -f "$VERSION_FILE" ]] || { echo "[FAIL] Missing $VERSION_FILE" >&2; exit 1; }
version="$(tr -d '[:space:]' < "$VERSION_FILE")"
[[ "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || {
  echo "[FAIL] Unexpected OpenTitan Bazel version: $version" >&2
  exit 1
}
expected="bazel $version"
install_dir="$HOME/.local/bin"
target="$install_dir/bazel"
mkdir -p "$install_dir"

check_bazel() {
  local candidate="$1"
  [[ -f "$candidate" && -x "$candidate" ]] || return 1
  [[ "$("$candidate" --version 2>/dev/null)" == "$expected" ]]
}

# 1. Already installed (for example after an earlier build layer).
if check_bazel "$target"; then
  echo "[BAZEL] $version already installed at $target"
  exit 0
fi

# 2. Prefer the actual Bazel executable left by Bazelisk in an existing image.
# This path is an offline operation and does not run Bazelisk/download anything.
cache="$HOME/.cache/bazelisk"
if [[ -d "$cache" ]]; then
  while IFS= read -r -d '' candidate; do
    if check_bazel "$candidate"; then
      cp "$candidate" "$target"
      chmod 755 "$target"
      echo "[BAZEL] Reused $version from existing Bazelisk cache"
      exit 0
    fi
  done < <(find "$cache" -type f \( -name bazel -o -name "bazel-$version-linux-x86_64" \) -print0 2>/dev/null)
fi

# 3. If an actual Bazel binary is installed elsewhere, reuse it. Do not execute
# the Bazelisk shim here: doing so could start an unwanted network download.
if [[ -x /usr/local/bin/bazel && ! /usr/local/bin/bazel -ef /usr/local/bin/bazelisk ]]    && check_bazel /usr/local/bin/bazel; then
  cp /usr/local/bin/bazel "$target"
  chmod 755 "$target"
  echo "[BAZEL] Reused already installed Bazel $version"
  exit 0
fi

# 4. Fresh image: download the pinned Bazel version from official release hosts.
# Resume interrupted transfers; retry on transient TLS EOFs.
file="bazel-${version}-linux-x86_64"
part="$target.part"
urls=(
  "https://releases.bazel.build/${version}/release/${file}"
  "https://github.com/bazelbuild/bazel/releases/download/${version}/${file}"
)
for url in "${urls[@]}"; do
  rm -f "$part"
  for attempt in 1 2 3; do
    echo "[BAZEL] Fetching $file (attempt $attempt/3) from $url"
    if curl --fail --location --show-error --retry 2 --retry-all-errors         --retry-delay 3 --connect-timeout 20 --max-time 240         --continue-at - --output "$part" "$url"; then
      chmod 755 "$part"
      if check_bazel "$part"; then
        mv -f "$part" "$target"
        echo "[BAZEL] Installed and checked $expected"
        exit 0
      fi
      echo "[BAZEL] Downloaded file has the wrong version or is incomplete" >&2
      rm -f "$part"
    fi
    sleep 3
  done
done
rm -f "$part"
echo "[FAIL] Bazel $version unavailable. Check network access to releases.bazel.build / GitHub." >&2
exit 1
