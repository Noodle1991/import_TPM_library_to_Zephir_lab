#!/usr/bin/env python3
import sys
import os

def find_kconfig(zephyr_base: str) -> str | None:
    candidates = [
        "soc/lowrisc/opentitan/Kconfig.defconfig",
        "soc/riscv/opentitan/Kconfig.defconfig",
        "soc/riscv32/opentitan/Kconfig.defconfig",
        "arch/riscv/soc/opentitan/Kconfig.defconfig",
    ]
    for candidate in candidates:
        full = os.path.join(zephyr_base, candidate)
        if os.path.exists(full):
            return full
    for root, dirs, files in os.walk(zephyr_base):
        if "Kconfig.defconfig" in files and "opentitan" in root.lower():
            return os.path.join(root, "Kconfig.defconfig")
    return None

def patch(path: str) -> None:
    with open(path, "r") as f:
        content = f.read()

    if "default 5000000" in content:
        print(f"[patch_kconfig] Already patched (5MHz): {path}")
        return

    original = content

    if "default 1000000" in content:
        content = content.replace("default 1000000", "default 5000000")

    if "SYS_CLOCK_TICKS_PER_SEC" not in content:
        content = content.replace(
            "default 5000000",
            "default 5000000\n\nconfig SYS_CLOCK_TICKS_PER_SEC\n\tdefault 1000",
            1,
        )

    if content != original:
        with open(path, "w") as f:
            f.write(content)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(1)

    arg = sys.argv[1]
    if os.path.isfile(arg):
        patch(arg)
    elif os.path.isdir(arg):
        found = find_kconfig(arg)
        if found:
            patch(found)
        else:
            sys.exit(1)
    else:
        sys.exit(1)
