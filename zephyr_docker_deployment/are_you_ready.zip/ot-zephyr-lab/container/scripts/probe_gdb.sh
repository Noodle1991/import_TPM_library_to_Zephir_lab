#!/usr/bin/env bash
# A noninteractive GDB probe. The OpenOCD server must already be listening on :3333.
# Prints real RISC-V register values from the simulated Ibex core and saves raw GDB output.
set -euo pipefail
source /home/dev/scripts/sim_helpers.sh

ELF="${1:?Usage: probe_gdb.sh <zephyr.elf> <gdb.log>}"
GDB_LOG="${2:?Usage: probe_gdb.sh <zephyr.elf> <gdb.log>}"
[[ -f "$ELF" ]] || { echo "[FAIL] ELF missing: $ELF" >&2; exit 1; }
mkdir -p "$(dirname "$GDB_LOG")"
resolve_debug_tools

echo '[GDB] Connecting to OpenOCD localhost:3333 (JTAG remote_bitbang 44853)'
echo '[GDB] Reading Ibex registers pc and sp, then resuming the target'
# Do not invent a PC value: let the debugger print the real register dump.
# `monitor resume` avoids leaving the RTL CPU paused after inspection.
set +e
timeout 120s "$GDB_BIN" -nx -q -batch "$ELF" \
  -ex 'set pagination off' \
  -ex 'set confirm off' \
  -ex 'set remotetimeout 60' \
  -ex 'target extended-remote 127.0.0.1:3333' \
  -ex 'monitor halt' \
  -ex 'info registers pc sp' \
  -ex 'monitor resume' \
  -ex 'disconnect' 2>&1 | tee "$GDB_LOG"
rc=${PIPESTATUS[0]}
set -e
if ((rc != 0)); then
  echo "[FAIL] GDB exited with status $rc; see $GDB_LOG" >&2
  exit "$rc"
fi
# The return code alone is not sufficient: require actual register readout.
if ! grep -Eq '^pc[[:space:]]+0x[[:xdigit:]]+' "$GDB_LOG" || \
   ! grep -Eq '^sp[[:space:]]+0x[[:xdigit:]]+' "$GDB_LOG"; then
  echo "[FAIL] GDB did not return both PC and SP; see $GDB_LOG" >&2
  exit 1
fi
echo '[PASS] GDB -> OpenOCD -> virtual JTAG: PC and SP retrieved'
