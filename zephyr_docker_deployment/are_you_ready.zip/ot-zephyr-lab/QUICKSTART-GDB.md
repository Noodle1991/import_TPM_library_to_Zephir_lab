# Zephyr + OpenTitan + GDB/OpenOCD — запуск на Mac

Нужен **Docker Desktop**, запущенный на Mac (Apple Silicon или Intel), доступ в интернет для первой сборки (при нестабильной сети загрузки могут прерываться) и достаточно свободного места для образа и Verilator. Исходники и инструменты устанавливаются **внутри** Docker-образа, не в macOS. Никаких дополнительных GDB/OpenOCD на Mac не требуется.

## Первый запуск после распаковки архива

```bash
cd ot-zephyr-lab
chmod +x scripts/*.sh container/scripts/*.sh
./scripts/setup-and-check.sh
```

Скрипт самостоятельно:
1. Использует `ot-zephyr-lab-gdb-ready:latest`, если нужный образ уже есть.
   Если на машине уже собран `ot-zephyr-lab:latest`, берёт его за основу и пересобирает только Verilator с исправлением JTAG/DMI. Пакеты Python/Zephyr не переустанавливаются. Bazel используется из кэша старого образа, если есть.
   Если готовой базы нет, собирает автономный образ `ot-zephyr-lab-gdb-ready:latest` целиком (потребуется интернет). Bazel 8.0.1 определяется по `.bazelversion`, загружается автоматически только при отсутствии в образе/кэше.
2. При первой сборке загружает Zephyr 3.7.0, OpenTitan на коммите `fee8a58ebe`, Zephyr SDK, Bazel и сопутствующие зависимости внутри Docker (не на Mac).
3. При сборке накладывает на файл OpenTitan `hw/dv/dpi/dmidpi/dmidpi.c` изменения из двух upstream-коммитов `f14af55` и `59a52a1` для JTAG/DMI.
4. Собирает Verilator, OpenOCD и пример `hello_world`.
5. Проверяет UART (`Hello World!`), затем связь OpenOCD (порт 44853) и GDB (порт 3333 внутри контейнера), печатает настоящие значения `pc`/`sp` и сохраняет логи в `logs/`.

Если проверка не прошла, скрипт вернёт ненулевой код. Лог в терминале и файлы `logs/smoke_hello_world.*.log` помогут понять причину. Успешная компиляция **не означает**, что GDB удалось подключить: этот шаг проверяется отдельно.

## Если Docker-образ уже готов

```bash
./scripts/check-debug-tools.sh
./scripts/smoke-test.sh
```

## Своё приложение

```bash
./scripts/build-app.sh myapp hello_demo
./scripts/debug-app.sh hello_demo
./scripts/gdb-snapshot.sh
./scripts/gdb-connect.sh
./scripts/stop-debug.sh
```

`debug-app.sh` поднимает временный контейнер с OpenOCD, а `gdb-connect.sh` запускает интерактивный GDB **внутри** него. Не требуется открывать порты Docker наружу.

## Отдельно от других проектов

По умолчанию используется тег `ot-zephyr-lab-gdb-ready:latest`, а не `ot-zephyr-lab:latest` из предыдущего проекта. Файлы `build/` и `logs/` создаются в каталоге **этой** распакованной копии. Скрипты не удаляют другие Docker-контейнеры и не вызывают `docker system prune`. Однако для одновременного запуска двух копий может потребоваться переименовать debug-контейнер (имя `ot-zephyr-debug` по умолчанию).

Для собственного имени образа можно использовать переменную:

```bash
OTZL_IMAGE_NAME=my-opentitan-gdb ./scripts/setup-and-check.sh
```

## Происхождение патча

Только официальные исправления lowRISC/OpenTitan: https://github.com/lowRISC/opentitan/pull/32394 (коммиты https://github.com/lowRISC/opentitan/commit/f14af55 и https://github.com/lowRISC/opentitan/commit/59a52a1). Патч не зависит от сторонних GitHub-форков. Порядок Rust-источников: официальный сервер, затем зеркала на случай недоступности; контрольные суммы артефактов сохраняет механизм Bazel.

*Примечание:* проект статически проверен по исходникам, но полный запуск Docker → Verilator → OpenOCD → GDB в среде разработки этого архива не выполнялся. Для утверждения «всё работает» необходим успешный запуск `setup-and-check.sh` на целевой машине.

## Если пропал интернет во время первой сборки

При `unexpected EOF` / `ReadTimeout` загрузка может быть прервана, несмотря на повторные попытки.
Проверьте доступность GitHub, PyPI и `releases.bazel.build`, затем повторите `./scripts/setup-and-check.sh`.
Docker BuildKit повторно использует успешно собранные слои. Полностью автономной от сети сборка из ZIP не является.

## Как работает выбор Bazel

В `container/scripts/ensure_bazel.sh` проверяется строго версия из `opentitan/.bazelversion` (для этого коммита — 8.0.1).
Сначала используется установленный бинарник, затем настоящий бинарник из кэша Bazelisk; только при отсутствии обоих выполняется загрузка с повторными попытками с двух официальных адресов.
Bazel/Bazelisk, установленные на macOS, не используются внутри Docker, и это намеренно.
